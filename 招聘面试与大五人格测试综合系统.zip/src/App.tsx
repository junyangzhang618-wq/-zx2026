/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  ClipboardCheck, 
  User, 
  GraduationCap, 
  Briefcase, 
  Wrench, 
  Brain, 
  CheckCircle, 
  ArrowRight, 
  ArrowLeft, 
  Download, 
  Redo, 
  Info, 
  AlertCircle, 
  PlayCircle,
  Laptop,
  UserRoundPen,
  Plus,
  Trash2,
  Settings,
  LogIn,
  LogOut,
  FileSpreadsheet,
  Database,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

import { 
  questions, 
  options, 
  dimensions, 
  dimensionQuestions 
} from './constants';
import { 
  Education, 
  WorkExperience, 
  Training, 
  Skills, 
  PersonalityScores, 
  Submission 
} from './types';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [currentStep, setCurrentStep] = useState(1);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [personalityAnswers, setPersonalityAnswers] = useState<number[]>(new Array(questions.length).fill(0));
  const [testCompleted, setTestCompleted] = useState(false);
  const [dimensionScores, setDimensionScores] = useState<PersonalityScores | null>(null);
  const [loading, setLoading] = useState(false);
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [submissions, setSubmissions] = useState<Submission[]>([]);

  // Form State
  const [formData, setFormData] = useState({
    jobPosition: '',
    interviewDate: new Date().toISOString().split('T')[0],
    availableDate: '',
    name: '',
    birthYear: '',
    birthMonth: '',
    birthDay: '',
    gender: '',
    maritalStatus: '',
    baseSalary: '',
    totalSalary: '',
    hometown: '',
    phone: '',
    address: '',
    education: [
      { eduDate: '', school: '', major: '', hasDegree: '' },
      { eduDate: '', school: '', major: '', hasDegree: '' }
    ] as Education[],
    workExperience: [
      { workDate: '', company: '', companySize: '', position: '', subordinates: '', baseSalary: '', totalSalary: '', leaveReason: '' },
      { workDate: '', company: '', companySize: '', position: '', subordinates: '', baseSalary: '', totalSalary: '', leaveReason: '' },
      { workDate: '', company: '', companySize: '', position: '', subordinates: '', baseSalary: '', totalSalary: '', leaveReason: '' }
    ] as WorkExperience[],
    training: {
      trainingDate: '',
      trainingOrg: '',
      trainingContent: ''
    } as Training,
    skills: {
      wordSkill: '',
      excelSkill: '',
      pptSkill: '',
      psSkill: '',
      aiSkill: '',
      prSkill: ''
    } as Skills,
    strengths: '',
    weaknesses: ''
  });

  const pdfRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const savedSubmissions = localStorage.getItem('submissions');
    if (savedSubmissions) {
      setSubmissions(JSON.parse(savedSubmissions));
    }
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleEducationChange = (index: number, field: keyof Education, value: string) => {
    const newEdu = [...formData.education];
    newEdu[index] = { ...newEdu[index], [field]: value };
    setFormData(prev => ({ ...prev, education: newEdu }));
  };

  const handleWorkChange = (index: number, field: keyof WorkExperience, value: string) => {
    const newWork = [...formData.workExperience];
    newWork[index] = { ...newWork[index], [field]: value };
    setFormData(prev => ({ ...prev, workExperience: newWork }));
  };

  const handleTrainingChange = (field: keyof Training, value: string) => {
    setFormData(prev => ({ ...prev, training: { ...prev.training, [field]: value } }));
  };

  const handleSkillChange = (field: keyof Skills, value: string) => {
    setFormData(prev => ({ ...prev, skills: { ...prev.skills, [field]: value } }));
  };

  const validateStep = (step: number) => {
    if (step === 1) {
      const required = ['jobPosition', 'interviewDate', 'availableDate', 'name', 'gender', 'phone', 'hometown', 'address', 'baseSalary', 'totalSalary', 'maritalStatus', 'birthYear', 'birthMonth', 'birthDay'];
      for (const field of required) {
        if (!formData[field as keyof typeof formData]) return false;
      }
    }
    if (step === 2) {
      if (!formData.education[0].eduDate || !formData.education[0].school || !formData.education[0].major || !formData.education[0].hasDegree) return false;
      if (!formData.workExperience[0].workDate || !formData.workExperience[0].company || !formData.workExperience[0].position) return false;
    }
    if (step === 3) {
      const requiredSkills = Object.values(formData.skills);
      if (requiredSkills.some(s => !s)) return false;
      if (!formData.strengths || !formData.weaknesses) return false;
    }
    return true;
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => prev + 1);
      window.scrollTo(0, 0);
    } else {
      alert('请填写所有必填字段');
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => prev - 1);
    window.scrollTo(0, 0);
  };

  const handlePersonalityAnswer = (value: number) => {
    const newAnswers = [...personalityAnswers];
    newAnswers[currentQuestionIndex] = value;
    setPersonalityAnswers(newAnswers);

    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(prev => prev + 1);
      } else {
        calculateResults(newAnswers);
      }
    }, 300);
  };

  const calculateResults = (answers: number[]) => {
    const scores: PersonalityScores = {
      neuroticism: 0,
      extraversion: 0,
      openness: 0,
      agreeableness: 0,
      conscientiousness: 0
    };

    for (const [dimension, qIds] of Object.entries(dimensionQuestions)) {
      let score = 0;
      qIds.forEach(id => {
        const qIndex = id - 1;
        let val = answers[qIndex];
        if (questions[qIndex].isQuestion15) {
          val = 6 - val;
        }
        score += val;
      });
      scores[dimension as keyof PersonalityScores] = score;
    }

    setDimensionScores(scores);
    setTestCompleted(true);
    setCurrentStep(5);

    const submission: Submission = {
      ...formData,
      timestamp: new Date().toLocaleString('zh-CN'),
      personalityScores: scores
    };

    const newSubmissions = [...submissions, submission];
    setSubmissions(newSubmissions);
    localStorage.setItem('submissions', JSON.stringify(newSubmissions));
  };

  const downloadReport = async () => {
    if (!pdfRef.current) return;
    setLoading(true);
    try {
      const canvas = await html2canvas(pdfRef.current, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
      pdf.save(`${formData.name}_${formData.jobPosition}_综合评估报告.pdf`);
    } catch (error) {
      console.error('PDF Error:', error);
      alert('生成报告失败');
    } finally {
      setLoading(false);
    }
  };

  const restart = () => {
    if (confirm('确定要重新开始吗？')) {
      window.location.reload();
    }
  };

  const loginAdmin = () => {
    if (adminPassword === 'zx123456') {
      setIsLoggedIn(true);
    } else {
      alert('密码错误');
    }
  };

  const exportCSV = () => {
    if (submissions.length === 0) return;
    let csv = "提交时间,姓名,求职岗位,性别,电话,神经质,外倾性,开放性,宜人性,尽责性\n";
    submissions.forEach(s => {
      csv += `"${s.timestamp}","${s.name}","${s.jobPosition}","${s.gender}","${s.phone}",${s.personalityScores.neuroticism},${s.personalityScores.extraversion},${s.personalityScores.openness},${s.personalityScores.agreeableness},${s.personalityScores.conscientiousness}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = '面试数据.csv';
    link.click();
  };

  const steps = [
    { id: 1, label: '基本信息', icon: User },
    { id: 2, label: '经历背景', icon: GraduationCap },
    { id: 3, label: '技能评价', icon: Wrench },
    { id: 4, label: '人格测试', icon: Brain },
    { id: 5, label: '完成', icon: CheckCircle }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-200 text-slate-900 p-4 md:p-8 font-sans">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <header className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-indigo-600 flex items-center justify-center gap-3 mb-2">
            <ClipboardCheck className="w-10 h-10" />
            招聘面试与大五人格测试综合系统
          </h1>
          <p className="text-slate-600">请填写面试信息并完成人格测试，生成您的专属评估报告</p>
        </header>

        {/* Step Indicator */}
        <div className="relative flex justify-between mb-12 px-2">
          <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-200 -translate-y-1/2 z-0" />
          {steps.map((step) => (
            <div key={step.id} className="relative z-10 flex flex-col items-center">
              <div 
                className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center border-4 border-white transition-all duration-300",
                  currentStep === step.id ? "bg-indigo-600 text-white scale-110 shadow-lg" : 
                  currentStep > step.id ? "bg-emerald-500 text-white" : "bg-slate-200 text-slate-400"
                )}
              >
                <step.icon className="w-5 h-5" />
              </div>
              <span className={cn(
                "mt-2 text-xs font-semibold",
                currentStep === step.id ? "text-indigo-600" : "text-slate-400"
              )}>
                {step.label}
              </span>
            </div>
          ))}
        </div>

        {/* Form Sections */}
        <AnimatePresence mode="wait">
          {currentStep === 1 && (
            <motion.div 
              key="step1"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white rounded-3xl shadow-xl p-6 md:p-8"
            >
              <h2 className="text-2xl font-bold text-indigo-600 flex items-center gap-2 mb-6">
                <User className="w-6 h-6" /> 基本信息
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div>
                  <label className="block text-sm font-semibold mb-2">求职岗位 <span className="text-red-500">*</span></label>
                  <input 
                    type="text" name="jobPosition" value={formData.jobPosition} onChange={handleInputChange}
                    className="w-full px-4 py-2 border-2 border-slate-100 rounded-xl focus:border-indigo-500 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">面试时间 <span className="text-red-500">*</span></label>
                  <input 
                    type="date" name="interviewDate" value={formData.interviewDate} onChange={handleInputChange}
                    className="w-full px-4 py-2 border-2 border-slate-100 rounded-xl focus:border-indigo-500 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">可到岗时间 <span className="text-red-500">*</span></label>
                  <input 
                    type="date" name="availableDate" value={formData.availableDate} onChange={handleInputChange}
                    className="w-full px-4 py-2 border-2 border-slate-100 rounded-xl focus:border-indigo-500 outline-none transition-all"
                  />
                </div>
              </div>

              <div className="bg-slate-50 rounded-2xl p-6">
                <h3 className="text-lg font-bold text-indigo-600 mb-4">个人资料</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold mb-2">姓名 <span className="text-red-500">*</span></label>
                    <input type="text" name="name" value={formData.name} onChange={handleInputChange} className="w-full px-4 py-2 border-2 border-white rounded-xl focus:border-indigo-500 outline-none bg-white" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">出生年月 <span className="text-red-500">*</span></label>
                    <div className="flex gap-2">
                      <input type="text" name="birthYear" placeholder="年" value={formData.birthYear} onChange={handleInputChange} className="w-full px-2 py-2 border-2 border-white rounded-xl text-center outline-none bg-white" />
                      <input type="text" name="birthMonth" placeholder="月" value={formData.birthMonth} onChange={handleInputChange} className="w-full px-2 py-2 border-2 border-white rounded-xl text-center outline-none bg-white" />
                      <input type="text" name="birthDay" placeholder="日" value={formData.birthDay} onChange={handleInputChange} className="w-full px-2 py-2 border-2 border-white rounded-xl text-center outline-none bg-white" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">性别 <span className="text-red-500">*</span></label>
                    <select name="gender" value={formData.gender} onChange={handleInputChange} className="w-full px-4 py-2 border-2 border-white rounded-xl outline-none bg-white">
                      <option value="">请选择</option>
                      <option value="男">男</option>
                      <option value="女">女</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">婚育状况 <span className="text-red-500">*</span></label>
                    <select name="maritalStatus" value={formData.maritalStatus} onChange={handleInputChange} className="w-full px-4 py-2 border-2 border-white rounded-xl outline-none bg-white">
                      <option value="">请选择</option>
                      <option value="未婚">未婚</option>
                      <option value="已婚未育">已婚未育</option>
                      <option value="已婚已育">已婚已育</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">期望无责底薪 <span className="text-red-500">*</span></label>
                    <input type="text" name="baseSalary" value={formData.baseSalary} onChange={handleInputChange} className="w-full px-4 py-2 border-2 border-white rounded-xl outline-none bg-white" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">期望综合薪资 <span className="text-red-500">*</span></label>
                    <input type="text" name="totalSalary" value={formData.totalSalary} onChange={handleInputChange} className="w-full px-4 py-2 border-2 border-white rounded-xl outline-none bg-white" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">户籍地 <span className="text-red-500">*</span></label>
                    <input type="text" name="hometown" value={formData.hometown} onChange={handleInputChange} className="w-full px-4 py-2 border-2 border-white rounded-xl outline-none bg-white" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">联系电话 <span className="text-red-500">*</span></label>
                    <input type="tel" name="phone" value={formData.phone} onChange={handleInputChange} className="w-full px-4 py-2 border-2 border-white rounded-xl outline-none bg-white" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold mb-2">现在住址 <span className="text-red-500">*</span></label>
                    <input type="text" name="address" value={formData.address} onChange={handleInputChange} className="w-full px-4 py-2 border-2 border-white rounded-xl outline-none bg-white" />
                  </div>
                </div>
              </div>

              <div className="flex justify-end mt-8">
                <button onClick={nextStep} className="bg-indigo-600 text-white px-8 py-3 rounded-full font-bold shadow-lg hover:bg-indigo-700 transition-all flex items-center gap-2">
                  下一步 <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          )}

          {currentStep === 2 && (
            <motion.div 
              key="step2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white rounded-3xl shadow-xl p-6 md:p-8"
            >
              <h2 className="text-2xl font-bold text-indigo-600 flex items-center gap-2 mb-6">
                <GraduationCap className="w-6 h-6" /> 教育与工作经历
              </h2>

              <div className="mb-8">
                <h3 className="text-lg font-bold text-slate-700 mb-4 flex items-center gap-2">
                  <GraduationCap className="w-5 h-5 text-indigo-500" /> 教育经历
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-slate-50">
                        <th className="p-3 text-left border text-sm">起止年月</th>
                        <th className="p-3 text-left border text-sm">学校名称</th>
                        <th className="p-3 text-left border text-sm">专业</th>
                        <th className="p-3 text-left border text-sm">学位</th>
                      </tr>
                    </thead>
                    <tbody>
                      {formData.education.map((edu, idx) => (
                        <tr key={idx}>
                          <td className="p-2 border"><input type="text" value={edu.eduDate} onChange={(e) => handleEducationChange(idx, 'eduDate', e.target.value)} className="w-full p-1 outline-none" /></td>
                          <td className="p-2 border"><input type="text" value={edu.school} onChange={(e) => handleEducationChange(idx, 'school', e.target.value)} className="w-full p-1 outline-none" /></td>
                          <td className="p-2 border"><input type="text" value={edu.major} onChange={(e) => handleEducationChange(idx, 'major', e.target.value)} className="w-full p-1 outline-none" /></td>
                          <td className="p-2 border">
                            <select value={edu.hasDegree} onChange={(e) => handleEducationChange(idx, 'hasDegree', e.target.value)} className="w-full p-1 outline-none">
                              <option value="">请选择</option>
                              <option value="是">是</option>
                              <option value="否">否</option>
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-lg font-bold text-slate-700 mb-4 flex items-center gap-2">
                  <Briefcase className="w-5 h-5 text-indigo-500" /> 工作经历
                </h3>
                <p className="text-xs text-slate-500 mb-2 italic">注：请按时间由近到远填写（最近的工作经历填在第一行）</p>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse min-w-[800px]">
                    <thead>
                      <tr className="bg-slate-50">
                        <th className="p-2 border text-xs">起止年月</th>
                        <th className="p-2 border text-xs">单位名称</th>
                        <th className="p-2 border text-xs">规模</th>
                        <th className="p-2 border text-xs">职位</th>
                        <th className="p-2 border text-xs">下属</th>
                        <th className="p-2 border text-xs">底薪</th>
                        <th className="p-2 border text-xs">总薪</th>
                        <th className="p-2 border text-xs">离职原因</th>
                      </tr>
                    </thead>
                    <tbody>
                      {formData.workExperience.map((work, idx) => (
                        <tr key={idx}>
                          <td className="p-1 border"><input type="text" value={work.workDate} onChange={(e) => handleWorkChange(idx, 'workDate', e.target.value)} className="w-full p-1 text-sm outline-none" /></td>
                          <td className="p-1 border"><input type="text" value={work.company} onChange={(e) => handleWorkChange(idx, 'company', e.target.value)} className="w-full p-1 text-sm outline-none" /></td>
                          <td className="p-1 border"><input type="text" value={work.companySize} onChange={(e) => handleWorkChange(idx, 'companySize', e.target.value)} className="w-full p-1 text-sm outline-none" /></td>
                          <td className="p-1 border"><input type="text" value={work.position} onChange={(e) => handleWorkChange(idx, 'position', e.target.value)} className="w-full p-1 text-sm outline-none" /></td>
                          <td className="p-1 border"><input type="text" value={work.subordinates} onChange={(e) => handleWorkChange(idx, 'subordinates', e.target.value)} className="w-full p-1 text-sm outline-none" /></td>
                          <td className="p-1 border"><input type="text" value={work.baseSalary} onChange={(e) => handleWorkChange(idx, 'baseSalary', e.target.value)} className="w-full p-1 text-sm outline-none" /></td>
                          <td className="p-1 border"><input type="text" value={work.totalSalary} onChange={(e) => handleWorkChange(idx, 'totalSalary', e.target.value)} className="w-full p-1 text-sm outline-none" /></td>
                          <td className="p-1 border"><input type="text" value={work.leaveReason} onChange={(e) => handleWorkChange(idx, 'leaveReason', e.target.value)} className="w-full p-1 text-sm outline-none" /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="flex justify-between mt-8">
                <button onClick={prevStep} className="border-2 border-indigo-600 text-indigo-600 px-8 py-3 rounded-full font-bold hover:bg-indigo-50 transition-all flex items-center gap-2">
                  <ArrowLeft className="w-5 h-5" /> 上一步
                </button>
                <button onClick={nextStep} className="bg-indigo-600 text-white px-8 py-3 rounded-full font-bold shadow-lg hover:bg-indigo-700 transition-all flex items-center gap-2">
                  下一步 <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          )}

          {currentStep === 3 && (
            <motion.div 
              key="step3"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white rounded-3xl shadow-xl p-6 md:p-8"
            >
              <h2 className="text-2xl font-bold text-indigo-600 flex items-center gap-2 mb-6">
                <Wrench className="w-6 h-6" /> 技能与自我评价
              </h2>

              <div className="mb-8">
                <h3 className="text-lg font-bold text-slate-700 mb-4 flex items-center gap-2">
                  <Laptop className="w-5 h-5 text-indigo-500" /> 软件技能熟练度
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {Object.keys(formData.skills).map((skillKey) => (
                    <div key={skillKey} className="bg-slate-50 p-4 rounded-2xl">
                      <label className="block text-sm font-bold mb-2 capitalize">{skillKey.replace('Skill', '')}</label>
                      <select 
                        value={formData.skills[skillKey as keyof Skills]} 
                        onChange={(e) => handleSkillChange(skillKey as keyof Skills, e.target.value)}
                        className="w-full p-2 bg-white border-2 border-transparent rounded-xl outline-none focus:border-indigo-500"
                      >
                        <option value="">请选择</option>
                        <option value="不熟练">不熟练</option>
                        <option value="一般">一般</option>
                        <option value="熟练">熟练</option>
                        <option value="非常熟练">非常熟练</option>
                        <option value="精通">精通</option>
                      </select>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-lg font-bold text-slate-700 mb-4 flex items-center gap-2">
                  <UserRoundPen className="w-5 h-5 text-indigo-500" /> 自我评价
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-bold mb-2">优势 <span className="text-red-500">*</span></label>
                    <textarea 
                      name="strengths" value={formData.strengths} onChange={handleInputChange} rows={4}
                      className="w-full px-4 py-3 border-2 border-slate-100 rounded-2xl focus:border-indigo-500 outline-none transition-all"
                      placeholder="请描述您的核心竞争力..."
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-2">劣势 <span className="text-red-500">*</span></label>
                    <textarea 
                      name="weaknesses" value={formData.weaknesses} onChange={handleInputChange} rows={4}
                      className="w-full px-4 py-3 border-2 border-slate-100 rounded-2xl focus:border-indigo-500 outline-none transition-all"
                      placeholder="请客观描述您的不足之处..."
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-between mt-8">
                <button onClick={prevStep} className="border-2 border-indigo-600 text-indigo-600 px-8 py-3 rounded-full font-bold hover:bg-indigo-50 transition-all flex items-center gap-2">
                  <ArrowLeft className="w-5 h-5" /> 上一步
                </button>
                <button onClick={nextStep} className="bg-indigo-600 text-white px-8 py-3 rounded-full font-bold shadow-lg hover:bg-indigo-700 transition-all flex items-center gap-2">
                  开始人格测试 <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          )}

          {currentStep === 4 && (
            <motion.div 
              key="step4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white rounded-3xl shadow-xl p-6 md:p-8"
            >
              {currentQuestionIndex === 0 && personalityAnswers[0] === 0 ? (
                <div className="text-center py-8">
                  <Brain className="w-20 h-20 text-indigo-600 mx-auto mb-6" />
                  <h2 className="text-3xl font-bold text-indigo-600 mb-4">大五人格测试</h2>
                  <div className="text-left bg-indigo-50 p-6 rounded-2xl mb-8">
                    <p className="text-slate-700 leading-relaxed mb-4">
                      大五人格模型是目前心理学界最受认可的人格特质理论，它将人格分为五个核心维度：神经质、外倾性、开放性、宜人性和尽责性。
                    </p>
                    <p className="text-slate-700 leading-relaxed mb-4">
                      本测试包含60道题目，请根据每个描述与您实际情况的符合程度进行选择。答案没有对错之分，请根据您的第一直觉作答。
                    </p>
                    <div className="flex items-start gap-3 text-sm text-indigo-600 font-semibold">
                      <AlertCircle className="w-5 h-5 flex-shrink-0" />
                      <span>您的测试数据将被严格保密，仅用于本次招聘评估。</span>
                    </div>
                  </div>
                  <button 
                    onClick={() => handlePersonalityAnswer(0)} // Just to trigger the first question
                    className="bg-indigo-600 text-white px-12 py-4 rounded-full font-bold text-xl shadow-xl hover:bg-indigo-700 transition-all flex items-center gap-2 mx-auto"
                  >
                    <PlayCircle className="w-6 h-6" /> 开始测试
                  </button>
                </div>
              ) : (
                <div>
                  <div className="mb-8">
                    <div className="flex justify-between items-end mb-2">
                      <span className="text-indigo-600 font-bold">测试进度</span>
                      <span className="text-slate-400 text-sm font-semibold">{currentQuestionIndex + 1} / {questions.length}</span>
                    </div>
                    <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}
                        className="h-full bg-indigo-600"
                      />
                    </div>
                  </div>

                  <div className="mb-12">
                    <span className="text-indigo-500 font-bold text-lg mb-2 block">问题 {currentQuestionIndex + 1}</span>
                    <h3 className="text-2xl font-bold text-slate-800 leading-tight">
                      {questions[currentQuestionIndex].text}
                    </h3>
                  </div>

                  <div className="space-y-4">
                    {options.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => handlePersonalityAnswer(option.value)}
                        className={cn(
                          "w-full p-5 text-left rounded-2xl border-2 transition-all flex justify-between items-center group",
                          personalityAnswers[currentQuestionIndex] === option.value 
                            ? "bg-indigo-600 border-indigo-600 text-white shadow-lg scale-[1.02]" 
                            : "bg-slate-50 border-slate-100 text-slate-700 hover:border-indigo-300 hover:bg-indigo-50"
                        )}
                      >
                        <span className="font-bold text-lg">{option.text}</span>
                        <span className={cn(
                          "text-sm font-bold px-3 py-1 rounded-full",
                          personalityAnswers[currentQuestionIndex] === option.value ? "bg-white/20" : "bg-slate-200"
                        )}>
                          {option.value} 分
                        </span>
                      </button>
                    ))}
                  </div>

                  <div className="mt-12 flex justify-between">
                    <button 
                      onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
                      disabled={currentQuestionIndex === 0}
                      className="text-slate-400 font-bold flex items-center gap-2 disabled:opacity-30"
                    >
                      <ArrowLeft className="w-5 h-5" /> 上一题
                    </button>
                    <div className="text-slate-400 text-sm italic flex items-center gap-2">
                      <Info className="w-4 h-4" /> 选择后将自动跳转
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {currentStep === 5 && (
            <motion.div 
              key="step5"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-3xl shadow-xl p-8 text-center"
            >
              <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-16 h-16" />
              </div>
              <h2 className="text-3xl font-bold text-slate-800 mb-2">提交成功！</h2>
              <p className="text-slate-500 mb-8">您的面试信息与人格测试已完成，报告已生成。</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                <button 
                  onClick={downloadReport}
                  className="bg-indigo-600 text-white p-6 rounded-3xl shadow-lg hover:bg-indigo-700 transition-all flex flex-col items-center gap-3 group"
                >
                  <Download className="w-8 h-8 group-hover:bounce" />
                  <span className="font-bold text-lg">下载综合评估报告</span>
                </button>
                <button 
                  onClick={restart}
                  className="bg-slate-100 text-slate-600 p-6 rounded-3xl hover:bg-slate-200 transition-all flex flex-col items-center gap-3 group"
                >
                  <Redo className="w-8 h-8 group-hover:rotate-180 transition-transform duration-500" />
                  <span className="font-bold text-lg">重新开始填写</span>
                </button>
              </div>

              <div className="bg-indigo-50 p-6 rounded-2xl text-left">
                <h3 className="font-bold text-indigo-600 flex items-center gap-2 mb-3">
                  <Info className="w-5 h-5" /> 报告包含内容：
                </h3>
                <ul className="text-sm text-slate-600 space-y-2 list-disc list-inside">
                  <li>个人基本信息与联系方式</li>
                  <li>完整的教育背景与工作经历</li>
                  <li>软件技能熟练度评估</li>
                  <li>大五人格五个维度的详细得分与分析</li>
                  <li>针对岗位的性格匹配度建议</li>
                </ul>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Admin Section */}
        <div className="mt-12 pt-12 border-t border-slate-200">
          {!isAdminMode ? (
            <button 
              onClick={() => setIsAdminMode(true)}
              className="text-slate-400 hover:text-indigo-600 text-sm font-semibold flex items-center gap-2 mx-auto transition-colors"
            >
              <Settings className="w-4 h-4" /> 后台管理入口
            </button>
          ) : (
            <div className="bg-white rounded-3xl shadow-lg p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-slate-700 flex items-center gap-2">
                  <Settings className="w-6 h-6 text-indigo-500" /> 后台管理面板
                </h2>
                <button onClick={() => setIsAdminMode(false)} className="text-slate-400 hover:text-red-500"><LogOut className="w-5 h-5" /></button>
              </div>

              {!isLoggedIn ? (
                <div className="text-center py-8">
                  <h3 className="font-bold mb-4">管理员登录</h3>
                  <div className="flex max-w-xs mx-auto gap-2">
                    <input 
                      type="password" 
                      placeholder="请输入管理员密码" 
                      value={adminPassword}
                      onChange={(e) => setAdminPassword(e.target.value)}
                      className="flex-1 px-4 py-2 border-2 border-slate-100 rounded-xl outline-none focus:border-indigo-500"
                    />
                    <button onClick={loginAdmin} className="bg-indigo-600 text-white px-4 py-2 rounded-xl"><LogIn className="w-5 h-5" /></button>
                  </div>
                  <p className="text-xs text-slate-400 mt-2">提示：默认密码为 zx123456</p>
                </div>
              ) : (
                <div>
                  <div className="flex flex-wrap gap-4 mb-8">
                    <button onClick={exportCSV} className="bg-emerald-500 text-white px-6 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-emerald-600 transition-all">
                      <FileSpreadsheet className="w-5 h-5" /> 导出 CSV
                    </button>
                    <button className="bg-indigo-500 text-white px-6 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-indigo-600 transition-all">
                      <Database className="w-5 h-5" /> 导出 JSON
                    </button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="bg-slate-50">
                          <th className="p-3 border text-left text-sm">时间</th>
                          <th className="p-3 border text-left text-sm">姓名</th>
                          <th className="p-3 border text-left text-sm">岗位</th>
                          <th className="p-3 border text-left text-sm">电话</th>
                          <th className="p-3 border text-left text-sm">人格得分 (N/E/O/A/C)</th>
                          <th className="p-3 border text-left text-sm">操作</th>
                        </tr>
                      </thead>
                      <tbody>
                        {submissions.map((s, idx) => (
                          <tr key={idx} className="hover:bg-slate-50">
                            <td className="p-3 border text-xs">{s.timestamp}</td>
                            <td className="p-3 border text-sm font-bold">{s.name}</td>
                            <td className="p-3 border text-sm">{s.jobPosition}</td>
                            <td className="p-3 border text-sm">{s.phone}</td>
                            <td className="p-3 border text-sm font-mono">
                              {s.personalityScores.neuroticism}/{s.personalityScores.extraversion}/{s.personalityScores.openness}/{s.personalityScores.agreeableness}/{s.personalityScores.conscientiousness}
                            </td>
                            <td className="p-3 border">
                              <button className="text-indigo-600 hover:text-indigo-800 mr-2"><FileText className="w-4 h-4" /></button>
                              <button 
                                onClick={() => {
                                  if(confirm('确定删除此记录？')) {
                                    const newSubs = submissions.filter((_, i) => i !== idx);
                                    setSubmissions(newSubs);
                                    localStorage.setItem('submissions', JSON.stringify(newSubs));
                                  }
                                }}
                                className="text-red-500 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <footer className="text-center mt-12 text-slate-400 text-sm">
          <p>© 2026 招聘面试与大五人格测试综合系统 | 数据加密存储</p>
        </footer>
      </div>

      {/* Loading Overlay */}
      {loading && (
        <div className="fixed inset-0 bg-white/80 backdrop-blur-sm z-[100] flex flex-col items-center justify-center">
          <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4" />
          <p className="text-indigo-600 font-bold">正在生成报告，请稍候...</p>
        </div>
      )}

      {/* PDF Template (Hidden) */}
      <div className="fixed -left-[9999px] -top-[9999px]">
        <div ref={pdfRef} className="w-[210mm] p-[20mm] bg-white text-slate-900 font-sans">
          <div className="border-b-4 border-indigo-600 pb-6 mb-8 text-center">
            <h1 className="text-3xl font-bold text-indigo-600 mb-2">招聘面试与大五人格测试综合评估报告</h1>
            <p className="text-slate-500 text-sm">生成时间：{new Date().toLocaleString('zh-CN')} | 报告编号：REP-{Date.now()}</p>
          </div>

          <section className="mb-8">
            <h2 className="text-xl font-bold text-indigo-600 border-b border-slate-200 pb-2 mb-4">一、候选人基本信息</h2>
            <div className="grid grid-cols-2 gap-y-3 text-sm">
              <p><strong>求职岗位：</strong>{formData.jobPosition}</p>
              <p><strong>面试时间：</strong>{formData.interviewDate}</p>
              <p><strong>可到岗时间：</strong>{formData.availableDate}</p>
              <p><strong>姓名：</strong>{formData.name}</p>
              <p><strong>出生年月：</strong>{formData.birthYear}年{formData.birthMonth}月{formData.birthDay}日</p>
              <p><strong>性别：</strong>{formData.gender}</p>
              <p><strong>婚育状况：</strong>{formData.maritalStatus}</p>
              <p><strong>期望底薪：</strong>{formData.baseSalary}</p>
              <p><strong>期望总薪：</strong>{formData.totalSalary}</p>
              <p><strong>联系电话：</strong>{formData.phone}</p>
              <p className="col-span-2"><strong>现在住址：</strong>{formData.address}</p>
            </div>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-bold text-indigo-600 border-b border-slate-200 pb-2 mb-4">二、教育背景</h2>
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="bg-slate-50">
                  <th className="p-2 border text-left">起止年月</th>
                  <th className="p-2 border text-left">学校名称</th>
                  <th className="p-2 border text-left">专业</th>
                  <th className="p-2 border text-left">学位</th>
                </tr>
              </thead>
              <tbody>
                {formData.education.map((edu, i) => edu.eduDate && (
                  <tr key={i}>
                    <td className="p-2 border">{edu.eduDate}</td>
                    <td className="p-2 border">{edu.school}</td>
                    <td className="p-2 border">{edu.major}</td>
                    <td className="p-2 border">{edu.hasDegree}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-bold text-indigo-600 border-b border-slate-200 pb-2 mb-4">三、工作经历</h2>
            <div className="space-y-4">
              {formData.workExperience.map((work, i) => work.workDate && (
                <div key={i} className="bg-slate-50 p-4 rounded-xl">
                  <div className="flex justify-between font-bold mb-2">
                    <span>{work.company}</span>
                    <span>{work.workDate}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <p><strong>职位：</strong>{work.position}</p>
                    <p><strong>规模：</strong>{work.companySize}人</p>
                    <p><strong>下属：</strong>{work.subordinates}人</p>
                    <p><strong>薪资：</strong>{work.baseSalary} / {work.totalSalary}</p>
                    <p className="col-span-2"><strong>离职原因：</strong>{work.leaveReason}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-bold text-indigo-600 border-b border-slate-200 pb-2 mb-4">四、大五人格测试结果</h2>
            {dimensionScores && Object.entries(dimensions).map(([key, dim]) => {
              const score = dimensionScores[key as keyof PersonalityScores];
              let level = "中等";
              if (score <= dim.lowScoreThreshold) level = "低分";
              else if (score >= dim.highScoreThreshold) level = "高分";

              return (
                <div key={key} className="mb-6 page-break-inside-avoid">
                  <div className="flex justify-between items-end mb-2">
                    <h3 className="font-bold text-slate-800">{dim.name}</h3>
                    <span className="text-indigo-600 font-bold">得分：{score} / 60 ({level})</span>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-xl text-xs leading-relaxed">
                    <p className="mb-2"><strong>维度解析：</strong>{dim.fullDesc}</p>
                    <p><strong>特征表现：</strong>{level === "低分" ? dim.lowScoreDesc : level === "高分" ? dim.highScoreDesc : "表现均衡，无明显极端倾向。"}</p>
                  </div>
                </div>
              );
            })}
          </section>

          <div className="mt-12 pt-8 border-t border-slate-200 text-center text-xs text-slate-400">
            <p>本报告由招聘面试与大五人格测试综合系统自动生成，仅供内部招聘参考。</p>
          </div>
        </div>
      </div>
    </div>
  );
}
