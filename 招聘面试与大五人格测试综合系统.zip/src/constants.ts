export const questions = [
  { id: 1, text: "我是一个充满烦恼的人", dimension: "neuroticism" },
  { id: 2, text: "我真心喜欢我遇到的大部分人", dimension: "extraversion" },
  { id: 3, text: "我喜欢浪费时间做白日梦", dimension: "openness" },
  { id: 4, text: "我不会怀疑或嘲讽别人的企图", dimension: "agreeableness" },
  { id: 5, text: "在工作中，我的效率比较高且能胜任岗位工作", dimension: "conscientiousness" },
  { id: 6, text: "我经常因为一些事而感到焦虑和恐惧", dimension: "neuroticism" },
  { id: 7, text: "我很喜欢和他人交谈", dimension: "extraversion" },
  { id: 8, text: "大自然和艺术的规律形态让我感觉极为奇妙", dimension: "openness" },
  { id: 9, text: "我不相信如果你允许别人占你便宜，很多人真的会占你便宜", dimension: "agreeableness" },
  { id: 10, text: "我会保持我的物品整洁", dimension: "conscientiousness" },
  { id: 11, text: "我经常感到紧张和心神不定", dimension: "neuroticism" },
  { id: 12, text: "我喜欢很多人在我周围的感觉", dimension: "extraversion" },
  { id: 13, text: "我对诗词歌赋比较有感觉，它们常能打动我", dimension: "openness" },
  { id: 14, text: "就算有必要，我也不会为了达到我的目标而去操纵别人", dimension: "agreeableness" },
  { id: 15, text: "我不是一个做事有条不紊的人", dimension: "conscientiousness", isQuestion15: true },
  { id: 16, text: "别人对待我的方式常让我感到愤怒", dimension: "neuroticism" },
  { id: 17, text: "当我阅读一首诗，或者欣赏一件艺术品时，我有时会感到兴奋或惊喜", dimension: "extraversion" },
  { id: 18, text: "比起单独工作，我更喜欢与团队一起工作", dimension: "openness" },
  { id: 19, text: "没有人觉得我是自私且以自我为中心的", dimension: "agreeableness" },
  { id: 20, text: "我好像总能把事情安排得井井有条", dimension: "conscientiousness" },
  { id: 21, text: "我经常感到寂寞或忧郁", dimension: "neuroticism" },
  { id: 22, text: "我愿意成为别人的领袖", dimension: "extraversion" },
  { id: 23, text: "我很少注意自己在不同环境下的情绪或感受", dimension: "openness" },
  { id: 24, text: "没有人觉得我是冷漠或爱算计的", dimension: "agreeableness" },
  { id: 25, text: "我会尽心尽力完成一切分配给我的工作", dimension: "conscientiousness" },
  { id: 26, text: "有时我感到自己一文不值", dimension: "neuroticism" },
  { id: 27, text: "我常常感到精力旺盛", dimension: "extraversion" },
  { id: 28, text: "当我找到做事情的正确方法之后，我还会尝试寻找其他可能的方法", dimension: "openness" },
  { id: 29, text: "我通常会尽力做到体贴和周到", dimension: "agreeableness" },
  { id: 30, text: "我常常能让自己保持可靠或可信", dimension: "conscientiousness" },
  { id: 31, text: "我经常感到忧郁或沮丧", dimension: "neuroticism" },
  { id: 32, text: "我的生活节奏很快", dimension: "extraversion" },
  { id: 33, text: "我经常会尝试新鲜事物或主动了解新鲜事物", dimension: "openness" },
  { id: 34, text: "大部分认识我的人都喜欢我", dimension: "agreeableness" },
  { id: 35, text: "如果我做出了承诺，通常我能贯彻到底", dimension: "conscientiousness" },
  { id: 36, text: "很多时候，当事情不对劲时，我会感到挫败或者想放弃", dimension: "neuroticism" },
  { id: 37, text: "我是一个十分活跃的人", dimension: "extraversion" },
  { id: 38, text: "我喜欢思考理论或抽象的概念", dimension: "openness" },
  { id: 39, text: "我宁愿与人合作，胜过与人竞争", dimension: "agreeableness" },
  { id: 40, text: "我有一个明确的方向，并能有条不紊地朝着它努力工作", dimension: "conscientiousness" },
  { id: 41, text: "有时候，我会羞愧地想要躲起来", dimension: "neuroticism" },
  { id: 42, text: "我喜欢身临其境，置身于事件中的感觉", dimension: "extraversion" },
  { id: 43, text: "我对思考宇宙的规律和人类的情况很感兴趣", dimension: "openness" },
  { id: 44, text: "就算我不喜欢某个人，我也不会让他知道", dimension: "agreeableness" },
  { id: 45, text: "我会努力完成我的目标", dimension: "conscientiousness" },
  { id: 46, text: "我经常感到自己不如别人", dimension: "neuroticism" },
  { id: 47, text: "我是一个乐观主义者", dimension: "extraversion" },
  { id: 48, text: "我对具有思考性的事物充满好奇", dimension: "openness" },
  { id: 49, text: "我很少与同事或家人起争执", dimension: "agreeableness" },
  { id: 50, text: "我凡事都追求卓越", dimension: "conscientiousness" },
  { id: 51, text: "我经常感到无助，并且希望有人能帮助我解决问题", dimension: "neuroticism" },
  { id: 52, text: "我是一个快乐、积极、乐观、开朗的人", dimension: "extraversion" },
  { id: 53, text: "我相信让学生听富有争议性的演讲不会混淆或误导他们的思想", dimension: "openness" },
  { id: 54, text: "我对自己的评价并不高", dimension: "agreeableness" },
  { id: 55, text: "我比较习惯按照自己的步调把事情办妥", dimension: "conscientiousness" },
  { id: 56, text: "当我处在极大的压力之下，我有时会感到自己濒临崩溃", dimension: "neuroticism" },
  { id: 57, text: "我很容易笑", dimension: "extraversion" },
  { id: 58, text: "我并不认为做道德决定的时候，一定要考虑专家权威的意见", dimension: "openness" },
  { id: 59, text: "在态度上，我常常比较顽固，不愿意妥协", dimension: "agreeableness" },
  { id: 60, text: "我不需要花很长时间就能安顿下来工作", dimension: "conscientiousness" }
];

export const options = [
  { value: 1, text: "十分不赞同" },
  { value: 2, text: "不太赞同" },
  { value: 3, text: "不能确定" },
  { value: 4, text: "比较赞同" },
  { value: 5, text: "十分赞同" }
];

export const dimensions = {
  neuroticism: {
    name: "神经质",
    lowScoreThreshold: 24,
    highScoreThreshold: 38,
    lowScoreDesc: "稳定、平静、放松、少情绪化、安全",
    highScoreDesc: "烦恼、紧张、易情绪化、焦虑",
    fullDesc: "神经质显著的人容易产生抑郁、焦虑、愤怒等消极情绪，对外界环境的刺激表现得比较敏感，情绪表现比较强烈，情绪控制能力比较差，常常被负面情绪所控制，有效应对外部压力的能力比较差；神经质不显著的人则比较不容易被情绪左右，通常情绪比较稳定，但没有消极情绪并不代表会有积极情绪。"
  },
  extraversion: {
    name: "外倾性",
    lowScoreThreshold: 26,
    highScoreThreshold: 42,
    lowScoreDesc: "谨慎、内省、冷静、不活跃、乐于做事、喜欢独处、寡言",
    highScoreDesc: "善交际、活跃、健谈、乐观、易引起别人的注意",
    fullDesc: "外倾性显著的人比较有活力，喜欢与人接触，比较热情，愿意冒险。这类人往往比较健谈，比较自信，总能引起别人的注意；外倾性不显著的人则比较安静，比较谨慎，喜欢独处，不喜欢与人接触，不善言辞，不愿意其他人注意到自己。"
  },
  openness: {
    name: "开放性",
    lowScoreThreshold: 32,
    highScoreThreshold: 47,
    lowScoreDesc: "讲实际、兴趣少、思维固化、不善于分析",
    highScoreDesc: "兴趣广泛、具有创新思维、富于想象",
    fullDesc: "开放性显著的人富有想象力和创造力，兴趣比较广泛，具备抽象思维，对艺术比较喜爱，喜欢追求美好的事物；开放性不显著的人则比较保守，喜欢传统和常规，喜欢比较具体的事物，喜欢按部就班。"
  },
  agreeableness: {
    name: "宜人性",
    lowScoreThreshold: 30,
    highScoreThreshold: 48,
    lowScoreDesc: "苛刻、挑剔、粗鲁、多疑、易怒、喜操控他人",
    highScoreDesc: "脾气好、容易信任别人、乐于助人、大度、直率",
    fullDesc: "宜人性显著的人为人友善、善解人意、慷慨大方，并且乐于助人，有时候甚至为了别人牺牲自己的利益，对人性持积极乐观的态度；宜人性不显著的人则不愿意帮助别人，较多疑，不关心别人的利益，把自己的利益放在其他人的利益之上。"
  },
  conscientiousness: {
    name: "尽责性",
    lowScoreThreshold: 36,
    highScoreThreshold: 44,
    lowScoreDesc: "无目标、懒散、粗心、意志薄弱、享乐型",
    highScoreDesc: "有条理、勤奋、自律、守时、细心、有毅力",
    fullDesc: "尽责性显著的人往往比较可靠、聪明，但比较单调乏味，做决策时比较谨慎，有时候是一个完美主义者，有时候是工作狂；尽责性不显著的人则比较有趣，但做事比较冲动，做决策时比较快，有时候说做就做，甚至会为了做一件事而不计后果。"
  }
};

export const dimensionQuestions = {
  neuroticism: [1, 6, 11, 16, 21, 26, 31, 36, 41, 46, 51, 56],
  extraversion: [2, 7, 12, 17, 22, 27, 32, 37, 42, 47, 52, 57],
  openness: [3, 8, 13, 18, 23, 28, 33, 38, 43, 48, 53, 58],
  agreeableness: [4, 9, 14, 19, 24, 29, 34, 39, 44, 49, 54, 59],
  conscientiousness: [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60]
};
