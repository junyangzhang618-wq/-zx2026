export interface Education {
  eduDate: string;
  school: string;
  major: string;
  hasDegree: string;
}

export interface WorkExperience {
  workDate: string;
  company: string;
  companySize: string;
  position: string;
  subordinates: string;
  baseSalary: string;
  totalSalary: string;
  leaveReason: string;
}

export interface Training {
  trainingDate: string;
  trainingOrg: string;
  trainingContent: string;
}

export interface Skills {
  wordSkill: string;
  excelSkill: string;
  pptSkill: string;
  psSkill: string;
  aiSkill: string;
  prSkill: string;
}

export interface PersonalityScores {
  neuroticism: number;
  extraversion: number;
  openness: number;
  agreeableness: number;
  conscientiousness: number;
}

export interface Submission {
  timestamp: string;
  jobPosition: string;
  interviewDate: string;
  availableDate: string;
  name: string;
  birthYear: string;
  birthMonth: string;
  birthDay: string;
  gender: string;
  maritalStatus: string;
  baseSalary: string;
  totalSalary: string;
  hometown: string;
  phone: string;
  address: string;
  education: Education[];
  workExperience: WorkExperience[];
  training: Training;
  skills: Skills;
  strengths: string;
  weaknesses: string;
  personalityScores: PersonalityScores;
}
